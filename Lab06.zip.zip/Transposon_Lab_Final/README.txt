ARTIFICIAL DNA AND TRANSPOSABLE ELEMENT DETECTOR
================================================
Final submission package | Standard-library Python application

ASSIGNMENT FROM THE BOARD
-------------------------
* Generate artificial DNA of 200 to 400 BASES in total.
* Simulate 3 or 4 transposable elements.
* Implement an application to find the START and END positions of TEs.
* Model terminal INVERTED repeats and flanking DIRECT repeats.
* Test several TE configurations, including inserting 2 or 3 within others.

IMPORTANT: 200-400 is the number of DNA bases, NOT lines.
FASTA shows 60 DNA bases per display line, plus a header.

QUICKEST WAY TO RUN ON WINDOWS
------------------------------
1. Extract ZIP. Open the extracted Transposon_Lab_Final folder in VS Code.
2. Double-click Run_App_Windows.bat, or in the VS Code terminal run:
       python transposon_detector.py
3. Set total bases (200-400), TE count (3 or 4), and select one case.
4. Click "1. Generate" then "2. Detect".
5. Read the colored TE locations and the start/end position table.
6. Choose "Export ALL cases" to save outputs from each case.

THREE CASES
-----------
CASE 1 - SEPARATED:
   3 or 4 TE insertions at well-spaced host DNA positions.

CASE 2 - NEARBY/TANDEM:
   Two TE insertions into nearby target sites; other TEs are elsewhere.
   Neighboring insertions do not physically share the same bases.

CASE 3 - NESTED/OVERLAPPING:
   3 TEs: T2 inserted inside T1, plus T3 inserted separately.
   4 TEs: T3 inserted inside T2, which is inside T1; T4 is separate.
   The start-end intervals are nested even though the TIRs remain intact.

THREE STAGES SHOWN IN THE BOARD'S INSERTION DIAGRAM
---------------------------------------------------
1. Host DNA contains a short target site.
2. A TE with an inverted repeat at each end is inserted at the site.
3. DNA repair fills the staggered gaps, yielding duplicate 5-base
   target-site sequences on the two sides of the transposon.

Representation:
   ... [TSD] [left TIR | TE body | right TIR] [TSD] ...
   Right TIR = reverse complement of left TIR (inverted repeats).
   Matching TSDs are DIRECT repeats (target-site duplication).

HOW DETECTION WORKS
-------------------
The program knows four artificial transposon families and their unique
left-TIR patterns. It scans the DNA for a left TIR and corresponding right
(reverse-complement) TIR and checks that 5-base TSD sequences match on each
side. It DOES NOT need to match the entire TE interior. This makes it
possible to detect an original TE after a second TE has inserted inside it.

The detector reports start/end as 1-based INCLUSIVE base positions.
It also gives region length, FASTA line numbers, direct repeats, and whether
the TE is nested inside another detected TE. Coordinates always refer to
DNA bases, not the FASTA header or line break characters.

COMMAND LINE
------------
Run GUI:
       python transposon_detector.py
Generate one example:
       python transposon_detector.py --generate --bases 320 --count 4 --case nested --out output
Generate all three cases:
       python transposon_detector.py --all-cases --bases 320 --count 4 --out output
Detect a supplied FASTA sequence:
       python transposon_detector.py --detect examples/4_transposons/separate/synthetic_dna.fasta
Run automated tests:
       python -m unittest discover -s tests -v

PACKAGE CONTENTS
----------------
transposon_detector.py   Full GUI, generator, detector, command line
Run_App_Windows.bat     Double-click Windows launcher
README.txt              Installation and explanation
Lab_Report.pdf          Submission-ready explanation, diagrams and results
examples/3_transposons  Three sample cases, each with 3 TEs
examples/4_transposons  Three sample cases, each with 4 TEs
tests/test_detector.py  Automated correctness and regression tests
Board_Requirements.txt  Transcription and interpretation of board photo
SUBMISSION_CHECKLIST.txt  Teacher submission checklist
app_screenshot.png      App screenshot for separated case
app_screenshot_nested.png  App screenshot for nested case

Each sample example contains:
* synthetic_dna.fasta           Artificial DNA, 60 bases/line
* detected_elements.csv         Positions and structural checks
* results.txt                   Human-readable result and mechanism
* double_stranded_dna.txt      Top and complementary DNA strands
* expected_positions.json       Generator truth for automated verification

DEPENDENCIES
------------
Python 3.10+ with built-in Tkinter is sufficient; no pip installs required.
The terminal version works even if Tkinter is missing.

LIMITATIONS
-----------
This is an EDUCATIONAL SIMULATION. The detector recognizes the four known
artificial TIR patterns and requires matching short direct repeats. It
cannot be treated as a general real-genome transposon identification tool.
