@echo off
cd /d "%~dp0"
where py >nul 2>&1
if not errorlevel 1 (
    py -3 transposon_detector.py
) else (
    python transposon_detector.py
)
if errorlevel 1 (
    echo.
    echo Ensure Python 3 with Tkinter is installed.
    pause
)
