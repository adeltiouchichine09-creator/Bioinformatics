"""Regression tests for artificial DNA lab. Run: python -m unittest discover -s tests -v"""
import tempfile
import unittest
from pathlib import Path

from transposon_detector import (
    CASE_DESCRIPTIONS, LINE_WIDTH, TRANSPOSONS, TSD_SIZE,
    complement, detect_elements, double_stranded_text, expected_coordinates,
    export_example, generate_dna, normalize_dna, read_fasta,
    reverse_complement, to_fasta, validate_result,
)


class TestTransposonLab(unittest.TestCase):
    def test_tir_is_reverse_complement(self):
        for te in TRANSPOSONS:
            self.assertEqual(te.right_tir, reverse_complement(te.tir))
            self.assertTrue(te.sequence.startswith(te.tir))
            self.assertTrue(te.sequence.endswith(te.right_tir))

    def test_all_cases_counts_lengths_and_seeds(self):
        for case in CASE_DESCRIPTIONS:
            for count in (3, 4):
                for length in (200, 201, 250, 300, 320, 399, 400):
                    for seed in (1, 2, 7, 42, 99):
                        with self.subTest(case=case, count=count, length=length, seed=seed):
                            dna, expected = generate_dna(length, count, case, seed)
                            found = detect_elements(dna)
                            self.assertEqual(len(dna), length)
                            self.assertTrue(set(dna).issubset(set("ACGT")))
                            self.assertEqual(len(found), count)
                            self.assertTrue(validate_result(expected, found))
                            self.assertEqual(len({d.name for d in found}), count)
                            for match in found:
                                self.assertEqual(dna[match.start - 1 - TSD_SIZE:match.start - 1], match.tsd_left)
                                self.assertEqual(dna[match.end:match.end + TSD_SIZE], match.tsd_right)
                                self.assertEqual(match.tsd_left, match.tsd_right)

    def test_three_distinct_case_relationships(self):
        for count in (3, 4):
            sep = detect_elements(generate_dna(320, count, "separate", 42)[0])
            tandem = detect_elements(generate_dna(320, count, "tandem", 42)[0])
            nested = detect_elements(generate_dna(320, count, "nested", 42)[0])
            self.assertTrue(all(d.parent == "-" for d in sep))
            self.assertTrue(all(d.parent == "-" for d in tandem))
            self.assertEqual(next(d for d in nested if d.name == "T2").parent, "T1")
            if count == 4:
                self.assertEqual(next(d for d in nested if d.name == "T3").parent, "T2")
            self.assertNotEqual([(d.start, d.end) for d in sep],
                                [(d.start, d.end) for d in tandem])

    def test_reject_invalid_lengths_counts_and_cases(self):
        for length in (0, 199, 401, 900):
            with self.assertRaises(ValueError):
                generate_dna(length)
        for count in (0, 2, 5):
            with self.assertRaises(ValueError):
                generate_dna(count=count)
        with self.assertRaises(ValueError):
            generate_dna(case="unknown")

    def test_detector_on_unrelated_dna(self):
        self.assertEqual(detect_elements("A" * 220), [])
        with self.assertRaises(ValueError):
            normalize_dna("CGTAX")

    def test_fasta_wrapping_roundtrip_and_output(self):
        dna, positions = generate_dna(320, 4, "nested", 42)
        fasta = to_fasta(dna)
        self.assertEqual(len(fasta.splitlines()) - 1, 6)
        self.assertTrue(all(len(line) <= LINE_WIDTH for line in fasta.splitlines()[1:]))
        text = double_stranded_text(dna)
        self.assertIn("3' " + complement(dna[:LINE_WIDTH]), text)
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "sample.fasta"
            path.write_text(fasta)
            self.assertEqual(read_fasta(path), dna)
            dest = Path(temp) / "export"
            matches = export_example(dest, 320, 4, "nested", 42)
            self.assertTrue(validate_result(positions, matches))
            for filename in ("synthetic_dna.fasta", "double_stranded_dna.txt",
                             "results.txt", "expected_positions.json", "detected_elements.csv"):
                self.assertTrue((dest / filename).is_file())


if __name__ == "__main__":
    unittest.main()
