"""Artificial DNA and transposable-element lab (Python 3, stdlib only).

Matches the board assignment: 200-400 BASES (not lines), 3-4 artificial TEs,
start/end detection, inverted terminal repeats, target-site duplications,
and multiple insertion cases including nested transposons.

All DNA sequences are synthetic. This is a teaching demonstration, not a
biological transposon annotation tool.
"""
from __future__ import annotations

import argparse
import csv
import json
import random
import re
from dataclasses import asdict, dataclass
from pathlib import Path

BASES = "ACGT"
COMPLEMENT = str.maketrans("ACGT", "TGCA")
TSD_SIZE = 5
LINE_WIDTH = 60
DEFAULT_BASES = 320
DEFAULT_COUNT = 4
DEFAULT_SEED = 42

CASE_DESCRIPTIONS = {
    "separate": "Case 1 - Three or four independent insertions spread along host DNA",
    "tandem": "Case 2 - Two nearby/tandem insertions plus other separated insertions",
    "nested": "Case 3 - Nested insertions (T2 inside T1; optionally T3 inside T2)",
}


def reverse_complement(dna: str) -> str:
    return dna.translate(COMPLEMENT)[::-1]


def complement(dna: str) -> str:
    return dna.translate(COMPLEMENT)


@dataclass(frozen=True)
class Transposon:
    name: str
    tir: str
    payload: str

    @property
    def sequence(self) -> str:
        return self.tir + self.payload + reverse_complement(self.tir)

    @property
    def right_tir(self) -> str:
        return reverse_complement(self.tir)


# Distinct recognition ends and distinct synthetic interiors. TIR means
# terminal inverted repeat; the right end is the reverse-complement of left.
TRANSPOSONS = (
    Transposon("T1", "ACGTTCGATA", "GGTTACGCAAGT"),
    Transposon("T2", "GCTAACGTGA", "ATCCTGACGTTA"),
    Transposon("T3", "TTAGCGATCA", "CAGTTCGGATAC"),
    Transposon("T4", "CCGATAGTTC", "TGCCTAACGATG"),
)


@dataclass
class Annotation:
    name: str
    start0: int  # zero-based inclusive
    end0: int    # zero-based exclusive, includes inner insertions if any
    tsd: str


@dataclass(frozen=True)
class Detection:
    name: str
    start: int  # one-based inclusive
    end: int    # one-based inclusive
    length: int
    first_line: int  # 1-based FASTA sequence row, excluding header
    last_line: int
    tir_left: str
    tir_right: str
    tsd_left: str
    tsd_right: str
    parent: str = "-"


def normalize_dna(text: str) -> str:
    dna = re.sub(r"\s+", "", text).upper()
    if not dna or set(dna) - set(BASES + "N"):
        raise ValueError("Sequence must contain only A, C, G, T or N.")
    return dna


def to_fasta(dna: str, heading: str = "Synthetic_DNA_Transposon_Lab") -> str:
    rows = [dna[i:i + LINE_WIDTH] for i in range(0, len(dna), LINE_WIDTH)]
    return ">" + heading + "\n" + "\n".join(rows) + "\n"


def read_fasta(path: Path) -> str:
    with path.open(encoding="utf-8") as stream:
        rows = [r.strip() for r in stream if r.strip() and not r.startswith(">")]
    return normalize_dna("".join(rows))


def insert_at(dna: str, te: Transposon, site: int,
              annotations: list[Annotation]) -> str:
    """Insert after a 5 bp target site and duplicate that target site.

    BEFORE:  ... ATGCA ...
    AFTER:   ... ATGCA [L-TIR | payload | R-TIR] ATGCA ...
    """
    if not TSD_SIZE <= site <= len(dna):
        raise ValueError("Insertion site out of DNA bounds.")
    tsd = dna[site - TSD_SIZE:site]
    added = te.sequence + tsd
    delta = len(added)
    for old in annotations:
        if site <= old.start0:  # insertion to left of this TE
            old.start0 += delta
            old.end0 += delta
        elif old.start0 < site < old.end0:  # insertion physically inside this TE
            old.end0 += delta
    annotations.append(Annotation(te.name, site, site + len(te.sequence), tsd))
    return dna[:site] + added + dna[site:]


def generate_dna(total_bases: int = DEFAULT_BASES,
                 count: int = DEFAULT_COUNT,
                 case: str = "separate",
                 seed: int = DEFAULT_SEED) -> tuple[str, list[Annotation]]:
    """Generate a final sequence with EXACTLY total_bases characters.

    Case 1: separated insertions; Case 2: two nearby; Case 3: nesting.
    All elements are inserted mechanically using duplicated target sites.
    """
    if not 200 <= total_bases <= 400:
        raise ValueError("DNA length must be between 200 and 400 BASES.")
    if count not in (3, 4):
        raise ValueError("Please choose 3 or 4 transposable elements.")
    if case not in CASE_DESCRIPTIONS:
        raise ValueError("Case must be separate, tandem, or nested.")
    selected = TRANSPOSONS[:count]
    background_length = total_bases - sum(len(t.sequence) + TSD_SIZE for t in selected)
    rng = random.Random(seed)
    host = "".join(rng.choices(BASES, k=background_length))
    annotations: list[Annotation] = []

    if case == "separate":
        positions = [round(background_length * (j + 1) / (count + 1))
                     for j in range(count)]
        # Reproduce the board's illustrated target site: ATGCA / TACGT.
        p1 = positions[0]
        host = host[:p1 - TSD_SIZE] + "ATGCA" + host[p1:]
        insertion_plan = sorted(zip(positions, selected), reverse=True,
                                key=lambda pair: pair[0])
        for p, te in insertion_plan:
            host = insert_at(host, te, p, annotations)

    elif case == "tandem":
        p1 = max(TSD_SIZE + 1, round(background_length * 0.20))
        p2 = p1 + TSD_SIZE  # neighboring sites, only 4 original bases apart
        if count == 3:
            positions = [p1, p2, round(background_length * 0.78)]
        else:
            positions = [p1, p2, round(background_length * 0.62),
                         round(background_length * 0.83)]
        host = host[:p1 - TSD_SIZE] + "ATGCA" + host[p1:]
        for p, te in sorted(zip(positions, selected), reverse=True,
                            key=lambda pair: pair[0]):
            host = insert_at(host, te, p, annotations)

    else:
        # Insert outside element(s) into independent host sites, then T1.
        # Subsequently insert T2 into the body of T1. For count=4, insert T3
        # into the body of T2 (three nested elements), while T4 is separate.
        separate = selected[-1]
        outer_site = round(background_length * 0.30)
        host = host[:outer_site - TSD_SIZE] + "ATGCA" + host[outer_site:]
        host = insert_at(host, separate, round(background_length * 0.78), annotations)
        host = insert_at(host, selected[0], outer_site, annotations)

        def inside_site(parent_name: str) -> int:
            p = next(a for a in annotations if a.name == parent_name)
            parent = next(t for t in TRANSPOSONS if t.name == parent_name)
            return p.start0 + len(parent.tir) + 7  # within parent payload, not TIR

        host = insert_at(host, selected[1], inside_site("T1"), annotations)
        if count == 4:
            host = insert_at(host, selected[2], inside_site("T2"), annotations)

    if len(host) != total_bases:
        raise AssertionError("Incorrect final DNA length.")
    annotations.sort(key=lambda a: (a.start0, -a.end0))
    return host, annotations


def detect_elements(dna: str) -> list[Detection]:
    """Detect predefined synthetic TE families by TIR pair + TSD evidence.

    Does NOT match entire transposon bodies, so elements inserted inside other
    elements can still be detected. Requires direct-repeat flanks (TSD).
    """
    dna = normalize_dna(dna)
    raw: list[Detection] = []
    for te in TRANSPOSONS:
        starts = [m.start() for m in re.finditer(re.escape(te.tir), dna)]
        ends = [m.end() for m in re.finditer(re.escape(te.right_tir), dna)]
        for start0 in starts:
            if start0 < TSD_SIZE:
                continue
            for end0 in ends:
                if end0 - start0 < len(te.sequence) or end0 + TSD_SIZE > len(dna):
                    continue
                left_tsd = dna[start0 - TSD_SIZE:start0]
                right_tsd = dna[end0:end0 + TSD_SIZE]
                if left_tsd != right_tsd:
                    continue
                raw.append(Detection(
                    name=te.name, start=start0 + 1, end=end0,
                    length=end0 - start0,
                    first_line=start0 // LINE_WIDTH + 1,
                    last_line=(end0 - 1) // LINE_WIDTH + 1,
                    tir_left=te.tir, tir_right=te.right_tir,
                    tsd_left=left_tsd, tsd_right=right_tsd,
                ))
    # Prevent duplicates; return in physical (start-of-sequence) order.
    unique = {(d.name, d.start, d.end): d for d in raw}
    ordered = sorted(unique.values(), key=lambda d: (d.start, -d.end))
    with_parents: list[Detection] = []
    for candidate in ordered:
        containers = [d for d in ordered
                      if d.name != candidate.name
                      and d.start < candidate.start and candidate.end < d.end]
        parent = min(containers, key=lambda d: d.length).name if containers else "-"
        with_parents.append(Detection(**{**asdict(candidate), "parent": parent}))
    return with_parents


def expected_coordinates(annotations: list[Annotation]) -> dict[str, tuple[int, int]]:
    return {a.name: (a.start0 + 1, a.end0) for a in annotations}


def validate_result(annotations: list[Annotation], matches: list[Detection]) -> bool:
    """Validate the independently detected coordinates against the generator truth."""
    return expected_coordinates(annotations) == {m.name: (m.start, m.end) for m in matches}


def double_stranded_text(dna: str) -> str:
    sections = ["DOUBLE-STRANDED DNA (the second line is the complementary strand)",
                "The top strand is read 5' -> 3'; the bottom runs 3' -> 5'.", ""]
    for start in range(0, len(dna), LINE_WIDTH):
        segment = dna[start:start + LINE_WIDTH]
        sections.append(f"Bases {start + 1}-{start + len(segment)}")
        sections.append("5' " + segment + " 3'")
        sections.append("3' " + complement(segment) + " 5'")
        sections.append("")
    return "\n".join(sections) + "\n"


def write_csv(matches: list[Detection], filename: Path) -> None:
    with filename.open("w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["transposon", "start_base", "end_base", "length_bp",
                         "start_line", "end_line", "left_TIR", "right_TIR",
                         "left_direct_repeat", "right_direct_repeat", "inside"])
        for d in matches:
            writer.writerow([d.name, d.start, d.end, d.length, d.first_line,
                             d.last_line, d.tir_left, d.tir_right,
                             d.tsd_left, d.tsd_right, d.parent])


def describe_results(matches: list[Detection], total_bases: int, case: str) -> str:
    rows = [CASE_DESCRIPTIONS[case],
            f"DNA length: {total_bases} bases | Transposons detected: {len(matches)}",
            "All positions are 1-based, and both start and end are included.",
            "The inverted repeats are the two terminal TIRs.",
            "The direct repeats are duplicated 5-base flanking target sites.", "",
            f"{'TE':<5} {'START':>6} {'END':>6} {'LENGTH':>7} {'INSIDE':>8} {'DIRECT REPEAT':>16}"]
    for d in matches:
        rows.append(f"{d.name:<5} {d.start:>6} {d.end:>6} {d.length:>7} "
                    f"{d.parent:>8} {d.tsd_left:>16}")
    rows += ["", "MECHANISM: Three stages shown on the board",
             "1. Unmodified host DNA contains a target site.",
             "2. A transposon with terminal inverted repeats inserts at that site.",
             "3. The gaps are filled, producing matching direct repeats on both sides.", "",
             "5' ... [TSD] [left TIR | payload | right TIR] [TSD] ... 3'",
             "The right TIR is the reverse complement of the left TIR.",
             "Nested cases preserve the outer TIRs and duplicated flanks."]
    return "\n".join(rows) + "\n"


def export_example(folder: Path, total_bases: int, count: int, case: str,
                   seed: int) -> list[Detection]:
    folder.mkdir(parents=True, exist_ok=True)
    dna, true_positions = generate_dna(total_bases, count, case, seed)
    detected = detect_elements(dna)
    if not validate_result(true_positions, detected) or len(detected) != count:
        raise AssertionError(f"Detection failed for {case} / {count} transposons.")
    (folder / "synthetic_dna.fasta").write_text(to_fasta(dna, f"{case}_{count}_transposons"),
                                                encoding="utf-8")
    (folder / "double_stranded_dna.txt").write_text(double_stranded_text(dna),
                                                     encoding="utf-8")
    (folder / "results.txt").write_text(describe_results(detected, total_bases, case),
                                        encoding="utf-8")
    (folder / "expected_positions.json").write_text(json.dumps({
        "case": case, "base_count": total_bases, "transposon_count": count,
        "positions_1_based_inclusive": {
            a.name: {"start": a.start0 + 1, "end": a.end0, "tsd": a.tsd}
            for a in true_positions
        }}, indent=2) + "\n", encoding="utf-8")
    write_csv(detected, folder / "detected_elements.csv")
    return detected


def print_results(matches: list[Detection], total_bases: int | None = None) -> None:
    if total_bases is not None:
        print(f"DNA length: {total_bases} bases")
    print("Detected transposons: " + str(len(matches)))
    print(f"{'Element':<10} {'Start':>6} {'End':>6} {'Length':>7} {'Inside':>8} {'TSD':>6}")
    for m in matches:
        print(f"{m.name:<10} {m.start:>6} {m.end:>6} {m.length:>7} {m.parent:>8} {m.tsd_left:>6}")


def run_gui() -> None:
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox

    class DNAApp(tk.Tk):
        COLORS = {"T1": "#f8df7f", "T2": "#a8e6cf", "T3": "#b6ccfa", "T4": "#f4bdd2"}

        def __init__(self) -> None:
            super().__init__()
            self.title("DNA Transposable Elements | 3 Cases")
            self.geometry("1170x850")
            self.minsize(940, 700)
            self.bases_var = tk.StringVar(value="320")
            self.count_var = tk.StringVar(value="4")
            self.case_var = tk.StringVar(value="Case 1 - Separated")
            self.seed_var = tk.StringVar(value="42")
            self.status_var = tk.StringVar(value="Generate a sequence, then detect the TEs.")
            self.dna = ""
            self.found: list[Detection] = []
            self.truth: list[Annotation] = []
            self.is_generated = False
            self.current_case = "separate"
            self.case_labels = {"Case 1 - Separated": "separate",
                                "Case 2 - Nearby/tandem": "tandem",
                                "Case 3 - Nested/overlapping": "nested"}

            title = ttk.Frame(self, padding=(12, 12, 12, 4))
            title.pack(fill="x")
            ttk.Label(title, text="Artificial DNA - Transposable Element Detector",
                      font=("Segoe UI", 17, "bold")).pack(anchor="w")
            ttk.Label(title, text="200-400 DNA bases | 3 or 4 TEs | terminal inverted repeats + direct repeats | three cases",
                      foreground="#4c5462").pack(anchor="w")

            settings = ttk.Frame(self, padding=(12, 10))
            settings.pack(fill="x")
            ttk.Label(settings, text="DNA bases:").pack(side="left")
            ttk.Spinbox(settings, from_=200, to=400, textvariable=self.bases_var, width=6).pack(side="left", padx=(5, 12))
            ttk.Label(settings, text="Transposons:").pack(side="left")
            ttk.Combobox(settings, textvariable=self.count_var, values=("3", "4"),
                         state="readonly", width=3).pack(side="left", padx=(5, 12))
            ttk.Label(settings, text="Case:").pack(side="left")
            ttk.Combobox(settings, textvariable=self.case_var,
                         values=list(self.case_labels), state="readonly", width=26).pack(side="left", padx=(5, 12))
            ttk.Label(settings, text="Seed:").pack(side="left")
            ttk.Entry(settings, textvariable=self.seed_var, width=6).pack(side="left", padx=(5, 10))
            ttk.Button(settings, text="1. Generate", command=self.on_generate).pack(side="left", padx=4)
            ttk.Button(settings, text="2. Detect", command=self.on_detect).pack(side="left", padx=4)

            actions = ttk.Frame(self, padding=(12, 0, 12, 8))
            actions.pack(fill="x")
            ttk.Button(actions, text="Open FASTA", command=self.on_open).pack(side="left", padx=(0, 8))
            ttk.Button(actions, text="Save current case", command=self.on_save).pack(side="left", padx=(0, 8))
            ttk.Button(actions, text="Export ALL cases", command=self.on_export_all).pack(side="left", padx=(0, 8))
            ttk.Button(actions, text="Show both DNA strands", command=self.on_strands).pack(side="left", padx=(0, 8))
            ttk.Button(actions, text="Insertion explanation", command=self.on_mechanism).pack(side="left")

            ttk.Label(self, text="DNA sequence (60 bases per FASTA line; header is not counted):",
                      padding=(12, 4)).pack(anchor="w")
            frame = ttk.Frame(self, padding=(12, 2, 12, 8))
            frame.pack(fill="both", expand=True)
            self.text = tk.Text(frame, font=("Consolas", 12), width=78, height=13,
                                background="#fcfcfc", wrap="none", state="normal")
            yscroll = ttk.Scrollbar(frame, orient="vertical", command=self.text.yview)
            xscroll = ttk.Scrollbar(frame, orient="horizontal", command=self.text.xview)
            self.text.configure(yscrollcommand=yscroll.set, xscrollcommand=xscroll.set)
            self.text.grid(row=0, column=0, sticky="nsew")
            yscroll.grid(row=0, column=1, sticky="ns")
            xscroll.grid(row=1, column=0, sticky="ew")
            frame.rowconfigure(0, weight=1)
            frame.columnconfigure(0, weight=1)
            for name, color in self.COLORS.items():
                self.text.tag_configure(name, background=color, foreground="#111111")

            ttk.Label(self, text="TE positions - one-based inclusive; Inside indicates nested insertions",
                      padding=(12, 4)).pack(anchor="w")
            columns = ("name", "start", "end", "length", "first", "last", "tsd", "parent")
            self.table = ttk.Treeview(self, columns=columns, show="headings", height=5)
            for col, title, width in zip(columns,
                    ("TE", "Start", "End", "Length (bp)", "First line", "Last line", "Direct repeat", "Inside"),
                    (75, 90, 90, 108, 100, 100, 130, 100)):
                self.table.heading(col, text=title)
                self.table.column(col, width=width, anchor="center")
            self.table.pack(fill="x", padx=12, pady=(0, 8))
            self.table.bind("<<TreeviewSelect>>", self.on_select)

            legend = ttk.Frame(self, padding=(12, 0, 12, 6))
            legend.pack(fill="x")
            for name in self.COLORS:
                ttk.Label(legend, text=f"  {name}  ", background=self.COLORS[name]).pack(side="left", padx=(0, 10))
            ttk.Label(legend, text="In the nested case, overlapping colored regions represent inserted TEs.").pack(side="left")
            ttk.Label(self, textvariable=self.status_var, relief="sunken", padding=9).pack(fill="x", side="bottom")
            self.on_generate()

        def show_dna(self) -> None:
            self.text.configure(state="normal")
            self.text.delete("1.0", "end")
            self.text.insert("1.0", to_fasta(self.dna))
            for name in self.COLORS:
                self.text.tag_remove(name, "1.0", "end")
            self.text.configure(state="disabled")
            self.found = []
            for item in self.table.get_children():
                self.table.delete(item)

        def on_generate(self) -> None:
            try:
                total = int(self.bases_var.get())
                count = int(self.count_var.get())
                seed = int(self.seed_var.get())
                self.current_case = self.case_labels[self.case_var.get()]
                self.dna, self.truth = generate_dna(total, count, self.current_case, seed)
                self.is_generated = True
            except (ValueError, KeyError) as exc:
                messagebox.showerror("Invalid settings", str(exc))
                return
            self.show_dna()
            self.status_var.set(f"Generated {len(self.dna)} bases with {count} TEs in {self.current_case} case. Click Detect.")

        def on_detect(self) -> None:
            if not self.dna:
                messagebox.showwarning("No DNA", "Generate or open a FASTA sequence first.")
                return
            self.found = detect_elements(self.dna)
            for item in self.table.get_children():
                self.table.delete(item)
            self.text.configure(state="normal")
            for name in self.COLORS:
                self.text.tag_remove(name, "1.0", "end")
            for i, m in enumerate(self.found):
                self.table.insert("", "end", iid=str(i), values=(m.name, m.start, m.end,
                    m.length, m.first_line, m.last_line, m.tsd_left, m.parent))
                start0 = m.start - 1
                end_excl = m.end
                a = f"{2 + start0 // LINE_WIDTH}.{start0 % LINE_WIDTH}"
                b = f"{2 + end_excl // LINE_WIDTH}.{end_excl % LINE_WIDTH}"
                self.text.tag_add(m.name, a, b)
                self.text.tag_raise(m.name)
            self.text.configure(state="disabled")
            verification = ""
            if self.is_generated:
                verification = " | generator verification: " + (
                    "PASS" if validate_result(self.truth, self.found) else "FAIL")
            self.status_var.set(f"Found {len(self.found)} TEs: base start/end positions shown below{verification}.")
            if self.found:
                self.table.selection_set("0")
                self.on_select(None)

        def on_select(self, _event) -> None:
            selected = self.table.selection()
            if not selected:
                return
            d = self.found[int(selected[0])]
            start0 = d.start - 1
            self.text.see(f"{2 + start0 // LINE_WIDTH}.{start0 % LINE_WIDTH}")

        def on_open(self) -> None:
            name = filedialog.askopenfilename(filetypes=[("FASTA files", "*.fasta *.fa *.fna *.txt"), ("All files", "*.*")])
            if not name:
                return
            try:
                self.dna = read_fasta(Path(name))
            except (OSError, ValueError) as exc:
                messagebox.showerror("Could not open FASTA", str(exc))
                return
            self.is_generated = False
            self.truth = []
            self.show_dna()
            self.status_var.set(f"Loaded {len(self.dna)} bases. Click Detect to scan for known TE families.")

        def on_save(self) -> None:
            if not self.dna:
                return
            target = filedialog.askdirectory(title="Choose a folder for this case's outputs")
            if not target:
                return
            folder = Path(target)
            (folder / "synthetic_dna.fasta").write_text(to_fasta(self.dna), encoding="utf-8")
            (folder / "double_stranded_dna.txt").write_text(double_stranded_text(self.dna), encoding="utf-8")
            matches = detect_elements(self.dna)
            write_csv(matches, folder / "detected_elements.csv")
            (folder / "results.txt").write_text(describe_results(matches, len(self.dna), self.current_case), encoding="utf-8")
            self.status_var.set(f"Case exported to {folder}.")

        def on_export_all(self) -> None:
            destination = filedialog.askdirectory(title="Choose the folder for all case examples")
            if not destination:
                return
            try:
                total = int(self.bases_var.get())
                count = int(self.count_var.get())
                seed = int(self.seed_var.get())
                for case in CASE_DESCRIPTIONS:
                    export_example(Path(destination) / case, total, count, case, seed)
            except (ValueError, OSError, AssertionError) as exc:
                messagebox.showerror("Export failed", str(exc))
                return
            self.status_var.set(f"All three case examples exported to {destination}.")
            messagebox.showinfo("Export complete", "Separate, nearby/tandem, and nested cases were saved.")

        def make_popup(self, heading: str, body: str) -> None:
            window = tk.Toplevel(self)
            window.title(heading)
            window.geometry("950x540")
            box = tk.Text(window, font=("Consolas", 11), wrap="none")
            box.insert("1.0", body)
            box.configure(state="disabled")
            scroll = ttk.Scrollbar(window, command=box.yview)
            box.configure(yscrollcommand=scroll.set)
            box.pack(side="left", fill="both", expand=True)
            scroll.pack(side="right", fill="y")

        def on_strands(self) -> None:
            if self.dna:
                self.make_popup("Both strands - complementary DNA", double_stranded_text(self.dna))

        def on_mechanism(self) -> None:
            body = (
                "THREE STAGES FROM THE BOARD\n\n"
                "STAGE 1: Host DNA before insertion\n"
                "         ... A T G C A ...\n"
                "         The 5-base target sequence is selected.\n\n"
                "STAGE 2: Transposon insertion (gaps still present conceptually)\n"
                "         ... A T G C A [ left TIR | TE payload | right TIR ] ...\n\n"
                "STAGE 3: Gaps are filled, creating target-site duplication\n"
                "         ... A T G C A [ left TIR | TE payload | right TIR ] A T G C A ...\n"
                "             ^ direct repeat                           ^ direct repeat\n\n"
                "INVERTED REPEATS: right TIR = reverse complement(left TIR).\n"
                "DIRECT REPEATS:  the same target-site bases appear on both sides.\n\n"
                "CASE 1: 3 or 4 independent, separated transposons.\n"
                "CASE 2: 2 transposons inserted close together (tandem) + others.\n"
                "CASE 3: Nested transposons. T2 is inside T1; with 4 total TEs,\n"
                "        T3 is inside T2 and T4 is elsewhere in the host.\n\n"
                "The detector finds known TIRs, their corresponding inverted ends,\n"
                "and duplicated target sites to infer start/end positions.\n"
                "It does not need to match the full TE interior, so nesting works.\n"
            )
            self.make_popup("How transposon insertion works", body)

    DNAApp().mainloop()


def main() -> None:
    parser = argparse.ArgumentParser(description="200-400 bp DNA generator and 3-case TE detector")
    commands = parser.add_mutually_exclusive_group()
    commands.add_argument("--generate", action="store_true", help="Generate one case and export its files")
    commands.add_argument("--all-cases", action="store_true", help="Export all three cases")
    commands.add_argument("--detect", type=Path, metavar="FILE", help="Detect TEs in FASTA file")
    parser.add_argument("--bases", type=int, default=DEFAULT_BASES, help="Final DNA length, 200..400")
    parser.add_argument("--count", type=int, choices=(3, 4), default=DEFAULT_COUNT, help="3 or 4 TEs")
    parser.add_argument("--case", choices=tuple(CASE_DESCRIPTIONS), default="separate")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--out", type=Path, default=Path(__file__).resolve().parent / "output")
    args = parser.parse_args()
    if args.generate:
        matches = export_example(args.out, args.bases, args.count, args.case, args.seed)
        print(CASE_DESCRIPTIONS[args.case])
        print_results(matches, args.bases)
        print(f"Output written to: {args.out}")
    elif args.all_cases:
        for case in CASE_DESCRIPTIONS:
            matches = export_example(args.out / case, args.bases, args.count, case, args.seed)
            print("\n" + CASE_DESCRIPTIONS[case])
            print_results(matches, args.bases)
        print(f"\nAll cases exported under: {args.out}")
    elif args.detect:
        sequence = read_fasta(args.detect)
        print_results(detect_elements(sequence), len(sequence))
    else:
        run_gui()


if __name__ == "__main__":
    main()
